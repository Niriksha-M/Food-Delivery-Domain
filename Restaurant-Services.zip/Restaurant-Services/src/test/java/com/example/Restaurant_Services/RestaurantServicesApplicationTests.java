package com.example.Restaurant_Services;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestaurantServicesApplicationTests {

	@Test
	void contextLoads() {
	}

}
